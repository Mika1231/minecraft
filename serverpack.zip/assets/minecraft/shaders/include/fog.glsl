#version 150

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    return inColor;
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    return 1.0;
}

float fog_distance(mat4 modelViewMat, vec3 pos, int shape) {
    return length((modelViewMat * vec4(pos, 1.0)).xyz);
}