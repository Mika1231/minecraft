Clean Fog - Minecraft Java 26.3 ONLY

This version is based on the final Minecraft 26.3 shader interfaces.
It disables normal fog in fog.glsl and the 26.3 terrain chunkVisibility fog fade.

Install:
1. Put this ZIP into .minecraft/resourcepacks
2. Disable/delete older Clean Fog versions
3. Enable only this pack

Target resource-pack version: 97.1
